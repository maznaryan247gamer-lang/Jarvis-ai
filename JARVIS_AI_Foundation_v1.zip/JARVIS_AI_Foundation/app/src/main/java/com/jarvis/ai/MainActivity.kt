package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF050B16)
private val Panel = Color(0xFF0B1728)
private val Cyan = Color(0xFF42D9FF)
private val Blue = Color(0xFF287BFF)
private val Muted = Color(0xFF8BA7C5)
private val WhiteBlue = Color(0xFFEAF8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                JarvisApp()
            }
        }
    }
}

@Composable
private fun JarvisApp() {
    var input by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("HOME") }
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage("JARVIS", "Good evening. JARVIS systems are online. My intelligence modules are not connected yet, but the foundation is ready.", false)
            )
        )
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF071426), Background, Color(0xFF02060D))
                    )
                )
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            Header()
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("HOME", "CHAT", "SYSTEM").forEach { tab ->
                    val active = selectedTab == tab
                    Button(
                        onClick = { selectedTab = tab },
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(9.dp),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) Color(0xFF123657) else Panel,
                            contentColor = if (active) Cyan else Muted
                        )
                    ) {
                        Text(tab, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            when (selectedTab) {
                "CHAT" -> {
                    Text("COMMUNICATION CHANNEL", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages) { msg -> MessageBubble(msg) }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Color(0xFF24415E), RoundedCornerShape(14.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f).padding(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = WhiteBlue, fontSize = 14.sp),
                            decorationBox = { inner ->
                                if (input.isEmpty()) Text("Type a message...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        )
                        Button(
                            onClick = {
                                if (input.isNotBlank()) {
                                    val sent = input.trim()
                                    messages = messages + ChatMessage("YOU", sent, true) +
                                        ChatMessage("JARVIS", "Message received. Connect an AI provider in the next development stage to enable intelligent replies.", false)
                                    input = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text("SEND", fontSize = 11.sp) }
                    }
                }
                "SYSTEM" -> {
                    Text("SYSTEM DIAGNOSTICS", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    StatusCard("CORE INTERFACE", "ONLINE", true)
                    StatusCard("OFFLINE AI / GEMMA", "NOT CONNECTED", false)
                    StatusCard("CLOUD AI", "NOT CONNECTED", false)
                    StatusCard("VOICE ENGINE", "NOT CONNECTED", false)
                    StatusCard("PHONE AUTOMATION", "NOT CONNECTED", false)
                    StatusCard("MEMORY DATABASE", "FOUNDATION READY", true)
                    Spacer(Modifier.height(12.dp))
                    Text("Version 1.0 • Foundation build", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.weight(1f))
                }
                else -> {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(Modifier.height(4.dp))
                            JarvisOrb()
                            Spacer(Modifier.height(8.dp))
                            Text("J.A.R.V.I.S.", color = WhiteBlue, fontSize = 25.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
                            Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Muted, fontSize = 8.sp, letterSpacing = 1.3.sp)
                            Spacer(Modifier.height(14.dp))
                            Text("SYSTEM STANDBY", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("SYSTEM MODULES", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        MiniModule("AI CORE", "PENDING", Modifier.weight(1f))
                        MiniModule("VOICE", "PENDING", Modifier.weight(1f))
                        MiniModule("VISION", "PENDING", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        MiniModule("MEMORY", "READY", Modifier.weight(1f))
                        MiniModule("AGENTS", "PENDING", Modifier.weight(1f))
                        MiniModule("ACTIONS", "PENDING", Modifier.weight(1f))
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Awaiting next instruction.", color = Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(16.dp))
                }
            }
            Text(
                "JARVIS AI  •  FOUNDATION V1.0",
                color = Color(0xFF47627E),
                fontSize = 9.sp,
                letterSpacing = 1.5.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("JARVIS", color = WhiteBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("PERSONAL AI INTERFACE", color = Muted, fontSize = 8.sp, letterSpacing = 1.5.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(Color(0xFF38E6A4), CircleShape))
            Spacer(Modifier.width(6.dp))
            Text("CORE ONLINE", color = Color(0xFF70EAC0), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun JarvisOrb() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(Color(0x5531BFFF), Color.Transparent)), radius = r * 0.95f, center = c)
            drawCircle(Cyan.copy(alpha = 0.55f), radius = r * 0.77f, center = c, style = Stroke(width = 2.dp.toPx()))
            drawCircle(Blue.copy(alpha = 0.8f), radius = r * 0.64f, center = c, style = Stroke(width = 1.dp.toPx()))
            drawCircle(Cyan.copy(alpha = 0.35f), radius = r * 0.48f, center = c, style = Stroke(width = 1.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(Color(0xFF1C8FCB), Color(0xFF07172D), Color(0xFF020711))), radius = r * 0.38f, center = c)
            drawCircle(Cyan.copy(alpha = 0.9f), radius = r * 0.23f, center = c, style = Stroke(width = 2.dp.toPx()))
            for (i in 0 until 36) {
                val angle = Math.toRadians(i * 10.0)
                val inner = r * 0.82f
                val outer = if (i % 3 == 0) r * 0.91f else r * 0.86f
                val start = Offset(c.x + kotlin.math.cos(angle).toFloat() * inner, c.y + kotlin.math.sin(angle).toFloat() * inner)
                val end = Offset(c.x + kotlin.math.cos(angle).toFloat() * outer, c.y + kotlin.math.sin(angle).toFloat() * outer)
                drawLine(Cyan.copy(alpha = if (i % 3 == 0) 0.85f else 0.35f), start, end, strokeWidth = if (i % 3 == 0) 2.dp.toPx() else 1.dp.toPx(), cap = StrokeCap.Round)
            }
        }
        Text("AI", color = WhiteBlue, fontSize = 31.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp)
    }
}

@Composable
private fun MiniModule(name: String, state: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Color(0xFF1C3853), RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Text(name, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(state, color = if (state == "READY") Color(0xFF65E6B4) else Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusCard(title: String, status: String, ready: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Color(0xFF1C3853), RoundedCornerShape(10.dp)).padding(13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = WhiteBlue, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Text(status, color = if (ready) Color(0xFF65E6B4) else Color(0xFFFFC66D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

private data class ChatMessage(val sender: String, val body: String, val fromUser: Boolean)

@Composable
private fun MessageBubble(message: ChatMessage) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.fromUser) Alignment.End else Alignment.Start
    ) {
        Text(message.sender, color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            message.body,
            color = WhiteBlue,
            fontSize = 13.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(if (message.fromUser) Color(0xFF12365B) else Panel, RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF24415E), RoundedCornerShape(12.dp))
                .padding(12.dp)
        )
    }
}
